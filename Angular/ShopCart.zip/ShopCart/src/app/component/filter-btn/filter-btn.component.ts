import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-filter-btn',
  templateUrl: './filter-btn.component.html',
  styleUrls: ['./filter-btn.component.css']
})
export class FilterBtnComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
